import React from "react";

//packages
import styled from "styled-components";

function LearningDashboard() {
    return (
        <Container>
            <Wrapper className="wrapper">
                <h3>tech schooling</h3>
                <Box>
                    <a href="#">Dashboard</a>
                    <a href="#">Learning</a>
                    <a href="#">Practices</a>
                    <a href="#">Workshops</a>
                    <a href="#">Assessments</a>
                    <a href="#">New Content</a>
                    <a href="#">Certification</a>
                </Box>
            </Wrapper>
        </Container>
    );
}

export default LearningDashboard;
const Container = styled.div`
    h3 {
        text-transform: capitalize;
        font-family: goridita_medium;
        font-size: 24px;
        margin-bottom: 19px;
    }
`;
const Box = styled.div`
    display: flex;
    margin-bottom: 35px;
    border-bottom: 1px solid rgb(232, 232, 232);
    a {
        color: rgb(113, 113, 113);
        font-size: 15px;
        margin-right: 32px;
        font-family: goridita_regular;
        &:hover {
            color: rgb(95, 209, 138);
            border-bottom: 3px solid rgb(95, 209, 138);
        }
    }
`;
const Wrapper = styled.div`
    width: 85%;
    margin: 0 auto;
    max-width: 1325px;
`;
