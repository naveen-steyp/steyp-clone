import React from "react";

//Packages

import styled from "styled-components";
import { useState } from "react";

//Images
import UiImage from "../../assets/image/UI_Engineer.jpg";
import StarImg from "../../assets/image/star.svg";
import SteypLogo from "../../assets/image/steyp-logo.svg";
import Backend from "../../assets/image/Backend_Developer_ACsVD3G.jpg";
import DevopImg from "../../assets/image/DevOps_Engineer.jpg";
import WebApp from "../../assets/image/Web_Application_Developer_vmaZxha.jpg";
import MobileApp from "../../assets/image/Mobile_Application_Developer.jpg";
import ErpApp from "../../assets/image/ERP_Developer.jpg";
import DataApp from "../../assets/image/Data_Scientist.jpg";
import MachineLearning from "../../assets/image/Robotics_Engineer__1.jpg";
import AiImg from "../../assets/image/AI_Engineer.jpg";
import BlockChain from "../../assets/image/Blockchain_Developer.jpg";
import ArImg from "../../assets/image/AR_Engineer.jpg";
import VrImg from "../../assets/image/VR_Engineer.jpg";
import IotImg from "../../assets/image/IoT_Engineer.jpg";
import RobotImg from "../../assets/image/Machine_Learning_Engineer.jpg";
import CalenderImg from "../../assets/image/calendar.svg";

function DashAchievements() {
    const [data, setData] = useState([
        {
            image: UiImage,
            name: "UI Engineer",
            description: "Completed on 21 May 2022",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: Backend,
            name: "Backend Developer",
            description: "Not enrolled yet  ",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: DevopImg,
            name: "DevOps Engineer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: WebApp,
            name: "Web Application Developer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: MobileApp,
            name: "Mobile Application Developer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: ErpApp,
            name: "ERP Developer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: DataApp,
            name: "Data Scientist",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: MachineLearning,
            name: " Machine Learning Engineer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: AiImg,
            name: " AI Engineer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: BlockChain,
            name: "Blockchain Developer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: ArImg,
            name: "AR Engineer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: VrImg,
            name: "VR Engineer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: IotImg,
            name: "IoT Engineer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
        {
            image: RobotImg,
            name: "Robotics Engineer",
            description: "Not enrolled yet",
            star: StarImg,
            steyp: SteypLogo,
        },
    ]);
    return (
        <Dash>
            <Wrapper className="wrapper">
                <h3>Achievements</h3>

                <Box>
                    <Left>
                        {data.map((items) => (
                            <Container>
                                <ImgContainer>
                                    <img src={items.image} alt="UIImage" />
                                </ImgContainer>
                                <Content>
                                    <span className="head">{items.name}</span>
                                    <span>{items.description}</span>
                                    <Star>
                                        <img src={items.star} alt="Star" />
                                        <img src={items.star} alt="Star" />
                                        <img src={items.star} alt="Star" />
                                        <img src={items.star} alt="Star" />
                                        <img src={items.star} alt="Star" />
                                        <img src={items.star} alt="Star" />
                                        <img src={items.star} alt="Star" />
                                        <img src={items.star} alt="Star" />
                                    </Star>
                                </Content>
                                <SteypImg>
                                    <img src={items.steyp} alt="Star" />
                                </SteypImg>
                            </Container>
                        ))}
                    </Left>
                    <Right>
                        <h3>Overall Performance</h3>
                        <Skill>
                            <Top>
                                <Performance>
                                    <Topic>
                                        <span>Lessons</span>
                                        <span className="number">96</span>
                                    </Topic>
                                    <Topic>
                                        <span>Topics</span>
                                        <span className="number">542</span>
                                    </Topic>
                                    <Profession>
                                        <Calender>
                                            <img
                                                src={CalenderImg}
                                                alt="Calender"
                                            />
                                        </Calender>
                                        <Text>
                                            <h5>Professions</h5>
                                            <span>1</span>
                                        </Text>
                                    </Profession>
                                    <Profession>
                                        <Calender>
                                            <img
                                                src={CalenderImg}
                                                alt="Calender"
                                            />
                                        </Calender>
                                        <Text>
                                            <h5>Skills</h5>
                                            <span>9</span>
                                        </Text>
                                    </Profession>
                                    <Profession>
                                        <Calender>
                                            <img
                                                src={CalenderImg}
                                                alt="Calender"
                                            />
                                        </Calender>
                                        <Text>
                                            <h5>Practices</h5>
                                            <span>26</span>
                                        </Text>
                                    </Profession>
                                    <Profession>
                                        <Calender>
                                            <img
                                                src={CalenderImg}
                                                alt="Calender"
                                            />
                                        </Calender>
                                        <Text>
                                            <h5>Assessments</h5>
                                            <span>16</span>
                                        </Text>
                                    </Profession>
                                    <Profession>
                                        <Calender>
                                            <img
                                                src={CalenderImg}
                                                alt="Calender"
                                            />
                                        </Calender>
                                        <Text>
                                            <h5>Workshops</h5>
                                            <span>26</span>
                                        </Text>
                                    </Profession>
                                    <Profession>
                                        <Calender>
                                            <img
                                                src={CalenderImg}
                                                alt="Calender"
                                            />
                                        </Calender>
                                        <Text>
                                            <h5>Premium Assists</h5>
                                            <span>0</span>
                                        </Text>
                                    </Profession>
                                </Performance>
                            </Top>
                        </Skill>
                    </Right>
                </Box>
            </Wrapper>
        </Dash>
    );
}

export default DashAchievements;
const Dash = styled.div`
    margin: 0px -23px;
    gap: 20px;
    padding: 0px 23px;
`;
const Wrapper = styled.div`
    width: 85%;
    margin: 0 auto;
    max-width: 1325px;
`;
const Box = styled.div`
    width: 100%;
    display: flex;
    justify-content: space-between;
`;
const Left = styled.div`
    width: 65%;
    display: grid;
    grid-template-columns: 1fr 1fr;
    column-gap: 15px;
`;
const Container = styled.div`
    width: 100%;
    background: rgb(232, 243, 253);
    padding: 16px 20px;
    border-radius: 5px;
    display: flex;
    position: relative;

    align-items: center;
    margin-bottom: 14px;
`;
const ImgContainer = styled.div`
    margin-right: 21px;
    width: 24%;
    img {
        width: 100%;
        display: block;
    }
`;
const Content = styled.div`
    display: flex;
    flex-direction: column;
    span.head {
    }
`;
const Star = styled.div``;
const SteypImg = styled.div`
    position: absolute;
    width: 35px;
    right: 26px;
    img {
        width: 100%;
        display: block;
    }
`;
const Right = styled.div`
    width: 30%;
    display: grid;
    grid-template-columns: 1fr;
    gap: 10px;
    min-width: 420px;
`;
const Skill = styled.div``;
const Top = styled.div``;
const Performance = styled.div``;
const Topic = styled.div`
    background: rgb(241, 238, 251);
    padding: 7px 17px;
    border-radius: 5px;
    display: flex;

    align-items: center;
    margin-bottom: 5px;
    justify-content: space-between;
    width: 100%;
`;
const Profession = styled.div`
    background: rgb(232, 243, 253);
    display: flex;

    align-items: center;
    padding: 16px;
    border-radius: 5px;
    margin-bottom: 5px;
`;
const Calender = styled.div`
    background: rgb(99, 231, 189);
    height: 44px;
    width: 44px;
    display: flex;
    align-items: center;

    justify-content: center;
    border-radius: 50%;
    margin-right: 11px;
`;
const Text = styled.div``;
