import React from "react";
import DashTech from "../../screens/DashTech";
import DashSlider from "../DashSlider";
import TechSchool from "./TechSchool";

const DashboardMain = () => {
    return (
        <div>
            <TechSchool />
            <DashSlider />
            <DashTech />
        </div>
    );
};

export default DashboardMain;
