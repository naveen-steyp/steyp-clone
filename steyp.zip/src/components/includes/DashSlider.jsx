import React from "react";

//Packages
import styled from "styled-components";

//Images
import DashImage from "../../assets/image/dashboard.svg";
import FreeImage from "../../assets/image/free.svg";
import ChallengeImage from "../../assets/image/challenge.svg";
import TalkImage from "../../assets/image/talk.svg";
import LinkednImage from "../../assets/image/linkedinsocial.svg";
import TwitterImage from "../../assets/image/twittersocial.svg";
import FacebookImage from "../../assets/image/facebooksocial.svg";
import InstagramImage from "../../assets/image/instagramsocail.svg";
import YoutubeImage from "../../assets/image/youtubesocial.svg";
import ExploreImage from "../../assets/image/explore-white-arrow.svg";

function DashSlider() {
    return (
        <Slider>
            <Top>
                <Box>
                    <ul>
                        <li>
                            <a href="#">
                                <Dash>
                                    <img src={DashImage} alt="Dash" />
                                </Dash>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <Free>
                                    <img src={FreeImage} alt="Free" />
                                </Free>
                                <span>Free Ground</span>
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <Challenge>
                                    <img src={ChallengeImage} alt="Challenge" />
                                </Challenge>
                                <span>Challenges</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <Talk>
                                    <img src={TalkImage} alt="Talk" />
                                </Talk>
                                <span>Chat with RM</span>
                            </a>
                        </li>
                    </ul>
                </Box>
            </Top>
            <Bottom>
                <ul>
                    <li>
                        <Social>
                            <a href="#">
                                <img src={LinkednImage} alt="Linkedn" />
                            </a>
                            <a href="#">
                                <img src={TwitterImage} alt="Twitter" />
                            </a>
                            <a href="#">
                                <img src={FacebookImage} alt="Facebook" />
                            </a>
                            <a href="#">
                                <img src={InstagramImage} alt="Instagram" />
                            </a>
                            <a href="#">
                                <img src={YoutubeImage} alt="Youtube" />
                            </a>
                        </Social>
                    </li>

                    <li className="explore">
                        <a href="#">
                            <span>Explore Talrop</span>
                            <button>
                                <img src={ExploreImage} alt="Explore" />
                            </button>
                        </a>
                    </li>
                </ul>
            </Bottom>
        </Slider>
    );
}

export default DashSlider;
const Slider = styled.div`
    background: rgb(249, 249, 251);
    width: 238px;
    border-top: 1px solid rgb(239, 239, 239);
    position: fixed;
    z-index: 100;
    height: 100vh;

    left: 0px;
    transition: all 0.2s ease-in-out 0s;
    min-height: 758px;
    overflow-y: scroll;

    flex-direction: column;

    justify-content: space-between;
    display: flex !important;
`;
const Top = styled.div``;
const Box = styled.div`
    ul {
        border-bottom: 1px solid #efefef;
        padding: 18px 0;
        width: 100%;
        margin-top: 60px;
    }
    li {
        :first-child {
            border-bottom: 1px solid #efefef;
            margin-bottom: 15px;
        }
        a {
            padding: 10px 20px;
            display: flex;
        }
    }
`;
const Dash = styled.div`
    width: 16px;
    max-height: 16px;
    display: block;
    margin-right: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
`;
const Free = styled.div`
    width: 16px;
    max-height: 16px;
    display: block;
    margin-right: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
`;
const Challenge = styled.div`
    width: 16px;
    max-height: 16px;
    display: block;
    margin-right: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
`;
const Talk = styled.div`
    width: 16px;
    max-height: 16px;
    display: block;
    margin-right: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
`;
const Bottom = styled.div`
    margin-bottom: 12px;
    ul {
        li.explore {
            display: flex;
            background: #56c082;
            max-height: 46px;
            display: flex;
            align-items: center;
            min-width: 60px;
            justify-content: center;
            align-items: center;

            button {
                outline: none;
                border: none;
                height: 45px;
            }
            span {
                font-family: goridita_medium;
                margin-right: 12px;
                color: rgb(255, 255, 255) !important;
                font-size: 14px;
            }
        }
    }
`;
const Social = styled.div`
    padding: 10px 21px;
    padding-bottom: 21px;
    display: flex;
    justify-content: space-between;
    a {
        width: 18px;
        margin-right: 15px;
    }
    img {
        width: 100%;
        display: block;
    }
`;
